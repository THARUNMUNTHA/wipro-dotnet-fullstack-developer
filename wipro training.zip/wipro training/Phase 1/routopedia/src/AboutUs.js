import React from 'react'

export const AboutUs = () => {
  return (

    <div>
      <br />
      <br/>
      <div>AboutUs</div>
  </div>
    

    
  )
}
