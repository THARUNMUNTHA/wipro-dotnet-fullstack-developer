import React from 'react'

export const CryptoGrpahy = () => {
  return (
    <div>CryptoGrpahy</div>
  )
}
