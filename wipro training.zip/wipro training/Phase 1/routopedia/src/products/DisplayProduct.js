import React from 'react'

function DisplayProduct() {
  return (
    <div>DisplayProduct</div>
  )
}

export default DisplayProduct