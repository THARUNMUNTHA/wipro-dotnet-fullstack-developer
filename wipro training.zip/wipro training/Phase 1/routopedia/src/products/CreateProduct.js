import React from 'react'

function CreateProduct() {
  return (
    <div>CreateProduct</div>
  )
}

export default CreateProduct