import React from 'react'

export const Home = () => {
  return (
    <div>Home</div>
  )
}
