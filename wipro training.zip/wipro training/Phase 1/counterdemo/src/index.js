import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import  App2  from './App2';
import App3 from './App3';
import './App.css'
import { Header } from './components/Header';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
<div>
    {/* <App />
    <App2 /> */}
    
    <App3/>
    </div>
  
);

