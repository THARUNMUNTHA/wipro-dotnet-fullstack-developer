﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CubeDemo
{
    public class CubeExample
    {
        public int FindCube(int x)
        {
            return x * x * x;
        }

    }
}
