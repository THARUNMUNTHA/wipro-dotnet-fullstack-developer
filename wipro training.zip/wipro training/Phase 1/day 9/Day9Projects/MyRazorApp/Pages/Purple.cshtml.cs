using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyApp.Namespace
{
    public class PurpleModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
