 const  Footer=()=>
{
return (
    <p style={{ color:"gray",backgroundColor:"black" }}> This is footer </p>
      )
}

export default Footer