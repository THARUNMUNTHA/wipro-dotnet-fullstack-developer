
const MainBody=(props)=>
{
  
  return (
          <div>
          <p>In this course we learn react by building {props.variable1} for {props.count} times </p>
          <ul>
          <li>Call Ben</li>
          <li>Go to walmart</li>
          </ul>
          </div>
      )
}


export {MainBody}