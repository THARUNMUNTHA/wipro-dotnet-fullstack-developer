import React from 'react'

export const dummy = () => {
  return (
    <div>dummy</div>
  )
}
