import './App.css';
import { ProductList } from './ProductList';
function App()
{
        return (
        <div className="App">
        <ProductList />
        </div>
        );
}
export default App;